package com.swapnil.cybage.demo_java_graphql;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoJavaGraphqlApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoJavaGraphqlApplication.class, args);
	}

}
